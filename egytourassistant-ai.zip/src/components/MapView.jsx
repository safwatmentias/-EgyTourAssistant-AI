import React from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import places from '../data/places.json';
import 'leaflet/dist/leaflet.css';

const MapView = () => {
  return (
    <div style={{ height: '400px' }}>
      <MapContainer center={[30.0444, 31.2357]} zoom={6} style={{ height: '100%', width: '100%' }}>
        <TileLayer
          attribution='&copy; <a href="https://osm.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {places.map((place, index) => (
          <Marker key={index} position={place.coordinates}>
            <Popup>
              <strong>{place.name}</strong><br />
              {place.description}
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
};

export default MapView;