import React from 'react';
import MapView from './components/MapView';
import CameraAndUpload from './components/CameraAndUpload';
import './i18n';
import { useTranslation } from 'react-i18next';

function App() {
  const { t } = useTranslation();

  return (
    <div>
      <h1>{t('welcome')}</h1>
      <CameraAndUpload />
      <MapView />
    </div>
  );
}

export default App;